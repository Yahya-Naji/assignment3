import { Provider } from 'react-redux';
import { store } from '../store/store'; 
import { AppProps } from 'next/app'; 
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/globals.css';

function Home({ Component, pageProps }: AppProps) {
  return (
    <Provider store={store}>
      <Component {...pageProps} />
    </Provider>
  );
}

export default Home;
