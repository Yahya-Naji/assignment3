import React, { useState } from 'react';
import TaskInput from '../src/components/TaskInput';
import TaskList from '../src/components/TaskList';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Task } from '../src/models/Task';
import Link from 'next/link';
import styles from '../styles/Home.module.css';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../store/store'; 
import { addTask, toggleTask, deleteTask } from '../store/tasksSlice';
// please note:  that i tried to wrap the components with provider an d then use the dispatch and reducer in index however an error saying i didnt wrap it kept prompting i kept the app.tsx to check how i wrapp it and ill ask you in person about this specific error but for the code to run i removed the dispatch ill keep the old code in note.txt so u see how i did it
const Home: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTab, setActiveTab] = useState<'active' | 'completed'>('active');

  const handleAddTask = (taskName: string) => {
    const newTask = {
      id: Date.now(), // Use a better ID generation strategy in a real app
      name: taskName,
      completed: false
    };
    setTasks([...tasks, newTask]);
  };

  const handleToggleTaskCompletion = (taskId: number) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, completed: !task.completed } : task
    ));
  };

  const handleDeleteTask = (taskId: number) => {
    setTasks(tasks.filter(task => task.id !== taskId));
  };

  const handleTabChange = (tab: 'active' | 'completed') => {
    setActiveTab(tab);
  };

  const filteredTasks = tasks.filter(task => 
    activeTab === 'active' ? !task.completed : task.completed
  );
  return (
    <div className="container mt-5">
      <TaskInput onAddTask={handleAddTask} />
      <ul className="nav nav-tabs my-4">
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'active' ? 'active' : ''}`}
            onClick={() => handleTabChange('active')}
          >
            Active Tasks
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'completed' ? 'active' : ''}`}
            onClick={() => handleTabChange('completed')}
          >
            Completed Tasks
          </button>
        </li>
      </ul>
      <div className="row">
        <div className="col">
          {activeTab === 'active' && (
            <TaskList
              tasks={tasks.filter(task => !task.completed)}
              onToggleTaskCompletion={handleToggleTaskCompletion}
              onDeleteTask={handleDeleteTask}
            />
          )}
          {activeTab === 'completed' && (
            <TaskList
              tasks={tasks.filter(task => task.completed)}
              onToggleTaskCompletion={handleToggleTaskCompletion}
              onDeleteTask={handleDeleteTask}
            />
          )}
        </div>
      </div>
      <div className="row">
        <div className="col">
        <Link href="/page_details">
  Go to Task Details
</Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
