import React from 'react';
import axios from 'axios';
import { TaskDetailsProps } from '../src/models/TaskDetailsProps'; 
const TaskDetails: React.FC<TaskDetailsProps> = ({ title, imageUrl }) => {
    return (
      <div>
        <h1>{title}</h1>
        <img src={imageUrl} alt={title} />
      </div>
    );
  };
  
  export async function getServerSideProps() {
    try {
      const response = await axios.get('https://dev-api.almashhad.tv/api/videos/detailsElastic/182622880654874');
      const result = response.data.data.result; 
      const title = result.title || 'Default Title';
  
     
      const imageUrl = result.image || ''; 
      return { props: { title, imageUrl } };
    } catch (error) {
      console.error('Failed to fetch task details:', error);
      return { props: { title: '', imageUrl: '' } };
    }
  }
  export default TaskDetails;