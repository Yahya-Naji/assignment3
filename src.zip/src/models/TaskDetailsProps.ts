export interface TaskDetailsProps {
    title: string;
    imageUrl: string;
  }